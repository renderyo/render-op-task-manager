import psutil
import tkinter as tk
from tkinter import messagebox
import os
import threading
import subprocess
from PIL import Image, ImageOps, ImageTk

class RenderOpTaskDestroyer:
    def __init__(self, root):
        self.root = root
        self.root.title("Render's OP Task Manager")
        self.root.geometry("800x600")
        self.root.resizable(True, True)

        # Set the window icon
        self.root.iconbitmap("yo.ico")

        # Get the current process ID to exclude from the list
        self.current_pid = os.getpid()

        # Page control variables
        self.current_page = 1
        self.max_pages = 2

        # Frame for the pages
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        # Create page frames
        self.page1_frame = tk.Frame(self.main_frame)
        self.page2_frame = tk.Frame(self.main_frame)

        self.page1_frame.pack(fill=tk.BOTH, expand=True)

        # Setup keyboard bindings
        self.root.bind("<Right>", self.next_page)
        self.root.bind("<Left>", self.previous_page)

        # Buttons for page 1
        self.create_page1()

        # Buttons for page 2
        self.create_page2()

        self.processes = []
        self.selected_pid = None

        self.refresh_processes()

    def next_page(self, event=None):
        """Navigate to the next page."""
        if self.current_page < self.max_pages:
            self.current_page += 1
            self.show_page()

    def previous_page(self, event=None):
        """Navigate to the previous page."""
        if self.current_page > 1:
            self.current_page -= 1
            self.show_page()

    def show_page(self):
        """Display the correct page based on the current page number."""
        # Hide all pages first
        self.page1_frame.pack_forget()
        self.page2_frame.pack_forget()

        # Show the current page
        if self.current_page == 1:
            self.page1_frame.pack(fill=tk.BOTH, expand=True)
        elif self.current_page == 2:
            self.page2_frame.pack(fill=tk.BOTH, expand=True)

    def create_page1(self):
        """Setup the first page with the process list and kill options."""
        # Frame for search bar and process list
        self.frame = tk.Frame(self.page1_frame)
        self.frame.pack(pady=10, fill=tk.BOTH, expand=True)

        # Search bar to filter processes
        self.search_var = tk.StringVar()
        self.search_var.trace("w", self.update_process_list)

        self.search_bar = tk.Entry(self.frame, textvariable=self.search_var, font=("Arial", 12))
        self.search_bar.pack(fill=tk.X, padx=10)

        # Create a Canvas widget to display the process list
        self.canvas = tk.Canvas(self.frame, bg="white")
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Create a scrollbar for the canvas
        self.scrollbar = tk.Scrollbar(self.frame, orient="vertical", command=self.canvas.yview)
        self.scrollbar.pack(side=tk.RIGHT, fill="y")
        self.canvas.config(yscrollcommand=self.scrollbar.set)

        # Frame to contain the process items inside the canvas
        self.process_frame = tk.Frame(self.canvas)
        self.canvas.create_window((0, 0), window=self.process_frame, anchor="nw")

        # Buttons to manage the process
        self.kill_button = tk.Button(self.page1_frame, text="Kill Process 200 Times", command=self.kill_selected_process, font=("Arial", 14))
        self.kill_button.pack(pady=5)

        self.refresh_button = tk.Button(self.page1_frame, text="Refresh Process List", command=self.refresh_processes, font=("Arial", 14))
        self.refresh_button.pack(pady=5)

        self.disable_kill_button = tk.Button(self.page1_frame, text="Disable Kill", command=self.disable_kill_process, font=("Arial", 14))
        self.disable_kill_button.pack(pady=5)

    def create_page2(self):
        """Setup the second page with additional options."""
        self.corrupt_button = tk.Button(self.page2_frame, text="Corrupt Process", command=self.corrupt_process, font=("Arial", 18))
        self.corrupt_button.pack(pady=50)

    def get_all_processes(self):
        """Gets all running processes on the system excluding the current script."""
        return [p.info for p in psutil.process_iter(attrs=['pid', 'name', 'exe']) if p.info['pid'] != self.current_pid]

    def update_process_list(self, *args):
        """Update the list of processes based on the search filter."""
        for widget in self.process_frame.winfo_children():
            widget.destroy()  # Clear the process list frame

        search_term = self.search_var.get().lower()
        self.processes = self.get_all_processes()
        filtered_processes = [proc for proc in self.processes if search_term in proc['name'].lower()]

        for proc in filtered_processes:
            proc_name = proc['name']
            proc_pid = proc['pid']
            proc_exe = proc['exe']

            display_text = f"{proc_name} (PID: {proc_pid})"
            process_frame = tk.Frame(self.process_frame)
            process_frame.pack(fill=tk.X, pady=5)

            # Load and display the process icon (exe image)
            try:
                icon = self.load_process_icon(proc_exe)
                icon_label = tk.Label(process_frame, image=icon)
                icon_label.image = icon  # Keep a reference
                icon_label.pack(side=tk.LEFT)

            except Exception as e:
                print(f"Error loading icon for {proc_name}: {e}")

            process_label = tk.Label(process_frame, text=display_text, font=("Arial", 12))
            process_label.pack(side=tk.LEFT, padx=10)

            # Bind click event to select process
            process_frame.bind("<Button-1>", lambda event, pid=proc_pid, label=process_label: self.select_process(pid, label))

        self.canvas.config(scrollregion=self.canvas.bbox("all"))

    def load_process_icon(self, exe_path):
        """Load the icon of the process."""
        try:
            icon = Image.open(exe_path)
            icon = ImageOps.fit(icon, (32, 32), method=0, bleed=0.0, box=None)
            icon = ImageTk.PhotoImage(icon)
            return icon
        except Exception as e:
            print(f"Could not load icon for {exe_path}: {e}")
            return None

    def refresh_processes(self):
        """Refresh the list of running processes."""
        self.processes = self.get_all_processes()
        self.update_process_list()

    def disable_kill_process(self):
        """Disable every thread of the selected process."""
        if not self.selected_pid:
            messagebox.showwarning("No Selection", "Please select a process.")
            return

        try:
            process = psutil.Process(self.selected_pid)
            for thread in process.threads():
                os.popen(f"taskkill /F /PID {self.selected_pid} >nul 2>&1")
                process.suspend()
            messagebox.showinfo("Disable Kill", "The process scripts have been disabled.")
        except psutil.NoSuchProcess:
            messagebox.showerror("Error", "Process not found.")

    def kill_selected_process(self):
        """Kill the selected process 200 times."""
        if not self.selected_pid:
            messagebox.showwarning("No Selection", "Please select a process to kill.")
            return

        for _ in range(200):
            try:
                process = psutil.Process(self.selected_pid)
                process.terminate()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                break

        messagebox.showinfo("Kill Process", f"Process {self.selected_pid} killed 200 times.")

    def select_process(self, pid, label):
        """Select the process and change its label color to green."""
        self.selected_pid = pid
        label.config(fg="green")  # Change the text color to green

    def corrupt_process(self):
        """Corrupt the selected process."""
        if not self.selected_pid:
            messagebox.showwarning("No Selection", "Please select a process to corrupt.")
            return

        try:
            process = psutil.Process(self.selected_pid)
            process.terminate()
            messagebox.showinfo("Corrupt", f"Process {self.selected_pid} corrupted.")
        except psutil.NoSuchProcess:
            messagebox.showerror("Error", "Process not found.")

    def show_task_manager(self):
        """Show the system's task manager."""
        if os.name == 'nt':  # If the operating system is Windows
            subprocess.Popen('taskmgr')
        else:
            messagebox.showwarning("Not Supported", "Task Manager is only available on Windows.")

# Run the GUI
if __name__ == "__main__":
    root = tk.Tk()
    app = RenderOpTaskDestroyer(root)
    root.mainloop()
